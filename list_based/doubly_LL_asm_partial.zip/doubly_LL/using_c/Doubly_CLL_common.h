#ifndef _DOUBLY_CLL_COMMON_H
#define _DOUBLY_CLL_COMMON_H

#include<stdio.h>

void* get_block(int no_of_blocks,int size_per_block);
#endif
